<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Marketplace\Product;
use App\Models\Marketplace\ProductCategory;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Collection;
use Illuminate\View\View;

class CategoryController extends Controller
{
    public function index(): View
    {
        $roots = ProductCategory::query()
            ->whereNull('parent_id')
            ->where('is_active', true)
            ->with(['children' => fn ($q) => $q->where('is_active', true)->orderBy('sort_order')->orderBy('name')])
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();

        $total = ProductCategory::where('is_active', true)->count();

        return view('frontend.categories.index', compact('roots', 'total'));
    }

    public function show(string $slug): View
    {
        $category = ProductCategory::query()
            ->where('slug', $slug)
            ->where('is_active', true)
            ->firstOrFail();

        $children = ProductCategory::query()
            ->where('parent_id', $category->id)
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();

        $products = Product::query()
            ->where('category_id', $category->id)
            ->published()
            ->latest('id')
            ->limit(24)
            ->get();

        $breadcrumb = $this->breadcrumb($category);
        $relatedLessons = $this->relatedLessons($category);

        return view('frontend.categories.show', compact('category', 'children', 'products', 'breadcrumb', 'relatedLessons'));
    }

    /**
     * @return array<int, array{name:string, url:string}>
     */
    private function breadcrumb(ProductCategory $category): array
    {
        $chain = [];
        $node = $category;
        $guard = 0;
        $publicBase = $this->publicBase();

        while ($node && $guard++ < 12) {
            array_unshift($chain, ['name' => $node->name, 'url' => $publicBase.'/categories/'.$node->slug]);
            $node = $node->parent;
        }

        return array_merge(
            [
                ['name' => 'Home', 'url' => $publicBase],
                ['name' => 'Categories', 'url' => $publicBase.'/categories'],
            ],
            $chain,
        );
    }

    private function publicBase(): string
    {
        $prefix = strtolower((string) request()->segment(1));
        if (! array_key_exists($prefix, config('neogiga_global.prefixes', []))) {
            $prefix = config('neogiga_global.default_prefix', 'en');
        }

        return '/'.$prefix;
    }

    /**
     * @return Collection<int, object>
     */
    private function relatedLessons(ProductCategory $category): Collection
    {
        try {
            if (! Schema::hasTable('category_lms_links')) {
                return collect();
            }

            $links = DB::table('category_lms_links as l')
                ->leftJoin('lms_courses as c', 'c.id', '=', 'l.lms_course_id')
                ->leftJoin('lms_projects as p', 'p.id', '=', 'l.lms_project_id')
                ->where('l.product_category_id', $category->id)
                ->where('l.is_active', true)
                ->select('l.title', 'l.relation_type', 'c.slug as course_slug', 'p.slug as project_slug')
                ->orderByDesc('l.id')
                ->limit(6)
                ->get();

            return $links->map(function ($link) {
                $link->url = $link->project_slug
                    ? '/learn/projects/'.$link->project_slug
                    : ($link->course_slug ? '/learn?course='.$link->course_slug : '/learn');

                return $link;
            });
        } catch (\Throwable) {
            return collect();
        }
    }
}
