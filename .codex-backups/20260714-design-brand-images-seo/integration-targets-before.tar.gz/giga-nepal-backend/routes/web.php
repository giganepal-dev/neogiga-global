<?php

use App\Http\Controllers\Admin\AuthController as AdminAuth;
use App\Http\Controllers\Admin\CommerceOpsController as AdminCommerce;
use App\Http\Controllers\Admin\CustomerDataController as AdminCustomerData;
use App\Http\Controllers\Admin\CustomerImportController as AdminCustomerImport;
use App\Http\Controllers\Admin\DashboardController as AdminDash;
use App\Http\Controllers\Admin\ElecforestImportController as AdminElecforestImport;
use App\Http\Controllers\Admin\MarketingActionController as AdminMarketing;
use App\Http\Controllers\Admin\MarketplaceConfigController as AdminMarketplaceConfig;
use App\Http\Controllers\HealthController;
use App\Http\Controllers\Web\AiCommercePageController;
use App\Http\Controllers\Web\CartPageController;
use App\Http\Controllers\Web\CategoryController;
use App\Http\Controllers\Web\EmailPreferenceController;
use App\Http\Controllers\Web\LandingController;
use App\Http\Controllers\Web\LmsPageController;
use App\Http\Controllers\Web\MarketplaceLandingController;
use App\Http\Controllers\Web\MarketplacePreferenceController;
use App\Http\Controllers\Web\PasswordResetController;
use App\Http\Controllers\Web\ProductPageController;
use App\Http\Controllers\Web\RedesignController;
use App\Http\Controllers\Web\RfqPageController;
use App\Http\Controllers\Web\SellOnNeoGigaController;
use App\Http\Controllers\Web\SeoLandingController;
use App\Http\Controllers\Web\SitemapController;
use App\Http\Controllers\Web\SsoController;
use App\Services\CommerceAi\CommerceAiService;
use App\Services\Lms\CourseCatalogService;
use Illuminate\Foundation\Http\Middleware\ValidateCsrfToken;
use Illuminate\Http\Request;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\Support\Facades\Route;
use Illuminate\View\Middleware\ShareErrorsFromSession;

/*
| Admin console (server-rendered). Reachable at /admin on any host; on
| admin.neogiga.com the root redirects to it. Registered BEFORE the public
| landing route so the admin host resolves to the console, not the landing.
*/
Route::domain('admin.neogiga.com')->get('/', fn () => redirect('/admin'));

Route::get('/health', HealthController::class)->withoutMiddleware([
    StartSession::class,
    ShareErrorsFromSession::class,
    ValidateCsrfToken::class,
]);

Route::get('/email/unsubscribe/{token}', [EmailPreferenceController::class, 'unsubscribe'])
    ->middleware('throttle:60,1')->name('email.unsubscribe');
Route::post('/email/unsubscribe/{token}', [EmailPreferenceController::class, 'confirmUnsubscribe'])
    ->middleware('throttle:10,1')->name('email.unsubscribe.confirm');
Route::get('/email/preferences/{token}', [EmailPreferenceController::class, 'preferences'])
    ->middleware('throttle:60,1')->name('email.preferences');
Route::patch('/email/preferences/{token}', [EmailPreferenceController::class, 'updatePreferences'])
    ->middleware('throttle:10,1')->name('email.preferences.update');

Route::prefix('admin')->group(function () {
    Route::get('login', [AdminAuth::class, 'showLogin'])->name('admin.login');
    Route::post('login', [AdminAuth::class, 'login'])->middleware('throttle:6,1');
    Route::post('logout', [AdminAuth::class, 'logout']);

    Route::middleware('admin.web')->group(function () {
        Route::get('/', [AdminDash::class, 'index']);
        Route::get('system-health', [AdminDash::class, 'systemHealth']);
        Route::get('categories', [AdminDash::class, 'categories']);
        Route::get('categories/{id}', [AdminDash::class, 'category'])->whereNumber('id');
        Route::get('products', [AdminDash::class, 'products']);
        Route::get('products/{id}', [AdminDash::class, 'product'])->whereNumber('id');
        Route::get('imports/jlcpcb', [AdminDash::class, 'jlcpcbImports']);
        Route::get('imports/elecforest', [AdminElecforestImport::class, 'index']);
        Route::post('imports/elecforest/start', [AdminElecforestImport::class, 'start'])->middleware('throttle:4,1');
        Route::post('imports/elecforest/runs/{run}/retry', [AdminElecforestImport::class, 'retry'])->whereUuid('run')->middleware('throttle:4,1');
        Route::post('imports/elecforest/runs/{run}/pause', [AdminElecforestImport::class, 'pause'])->whereUuid('run')->middleware('throttle:4,1');
        Route::post('imports/elecforest/runs/{run}/resume', [AdminElecforestImport::class, 'resume'])->whereUuid('run')->middleware('throttle:4,1');
        Route::post('imports/elecforest/generate-seo', [AdminElecforestImport::class, 'generateSeo'])->middleware('throttle:4,1');
        Route::post('imports/elecforest/download-images', [AdminElecforestImport::class, 'downloadImages'])->middleware('throttle:4,1');
        Route::post('imports/elecforest/publish-qualified', [AdminElecforestImport::class, 'publish'])->middleware('throttle:4,1');
        Route::post('imports/elecforest/map-category', [AdminElecforestImport::class, 'mapCategory'])->middleware('throttle:10,1');
        Route::post('imports/jlcpcb/bulk-approve', [AdminCommerce::class, 'bulkApproveJlcpcbImports'])->middleware('throttle:10,1');
        Route::post('imports/jlcpcb/bulk-publish', [AdminCommerce::class, 'bulkPublishJlcpcbImports'])->middleware('throttle:10,1');
        Route::post('imports/jlcpcb/search-rebuild', [AdminCommerce::class, 'queueJlcpcbSearchRebuild'])->middleware('throttle:5,1');
        Route::post('imports/jlcpcb/{source}/approve', [AdminCommerce::class, 'approveJlcpcbImport'])->whereNumber('source')->middleware('throttle:20,1');
        Route::post('imports/jlcpcb/{source}/publish', [AdminCommerce::class, 'publishJlcpcbImport'])->whereNumber('source')->middleware('throttle:10,1');
        Route::post('imports/jlcpcb/{source}/reject', [AdminCommerce::class, 'rejectJlcpcbImport'])->whereNumber('source')->middleware('throttle:20,1');
        Route::get('marketplaces', [AdminMarketplaceConfig::class, 'index']);
        Route::post('marketplaces/bulk', [AdminMarketplaceConfig::class, 'bulk'])->middleware('throttle:20,1');
        // Marketplace domain/SEO/status configuration UI (codex §3, §11).
        Route::get('marketplaces/{id}/config', [AdminMarketplaceConfig::class, 'edit'])->whereNumber('id');
        Route::post('marketplaces/{id}/config', [AdminMarketplaceConfig::class, 'update'])->whereNumber('id')->middleware('throttle:30,1');
        Route::post('marketplaces/{id}/enable', [AdminMarketplaceConfig::class, 'enable'])->whereNumber('id')->middleware('throttle:20,1');
        Route::post('marketplaces/{id}/disable', [AdminMarketplaceConfig::class, 'disable'])->whereNumber('id')->middleware('throttle:20,1');
        Route::post('marketplaces/{id}/generate-domain', [AdminMarketplaceConfig::class, 'generateDomain'])->whereNumber('id')->middleware('throttle:20,1');
        Route::post('marketplaces/{id}/verify-domain', [AdminMarketplaceConfig::class, 'verifyDomain'])->whereNumber('id')->middleware('throttle:20,1');
        Route::post('marketplaces/{id}/generate-seo', [AdminMarketplaceConfig::class, 'generateSeo'])->whereNumber('id')->middleware('throttle:20,1');
        Route::post('marketplaces/{id}/clear-cache', [AdminMarketplaceConfig::class, 'clearCache'])->whereNumber('id')->middleware('throttle:20,1');
        Route::get('vendors', [AdminDash::class, 'vendors']);
        Route::get('distributors', [AdminDash::class, 'distributors']);
        Route::get('users', [AdminDash::class, 'users']);
        Route::get('lms', [AdminDash::class, 'lms']);
        Route::get('lms/courses/{course}', [AdminDash::class, 'lmsCourse'])->whereNumber('course');
        Route::get('bom-imports', [AdminDash::class, 'bomImports']);
        Route::get('inventory', [AdminDash::class, 'inventory']);
        Route::get('pos', [AdminDash::class, 'pos']);
        Route::get('pos/sales/{sale}', [AdminDash::class, 'posSale'])->whereNumber('sale');
        Route::get('settings', [AdminDash::class, 'settings']);
        Route::get('media', [AdminDash::class, 'media']);
        Route::get('seo', [AdminDash::class, 'seo']);
        Route::post('settings/admin-settings', [AdminCommerce::class, 'storeAdminSetting'])->middleware('throttle:20,1');
        Route::delete('settings/admin-settings/{setting}', [AdminCommerce::class, 'deleteAdminSetting'])->whereNumber('setting')->middleware('throttle:20,1');
        Route::post('media/assets', [AdminCommerce::class, 'storeMediaAsset'])->middleware('throttle:10,1');
        Route::delete('media/assets/{asset}', [AdminCommerce::class, 'deleteMediaAsset'])->whereNumber('asset')->middleware('throttle:20,1');
        Route::post('seo/pages', [AdminCommerce::class, 'storeSeoPage'])->middleware('throttle:20,1');
        Route::post('seo/redirects', [AdminCommerce::class, 'storeSeoRedirect'])->middleware('throttle:20,1');
        Route::delete('seo/redirects/{redirect}', [AdminCommerce::class, 'deleteSeoRedirect'])->whereNumber('redirect')->middleware('throttle:20,1');
        Route::post('categories', [AdminCommerce::class, 'storeCategory'])->middleware('throttle:20,1');
        Route::post('categories/{category}/toggle', [AdminCommerce::class, 'deactivateCategory'])->whereNumber('category')->middleware('throttle:20,1');
        Route::post('categories/{category}/lms-links', [AdminCommerce::class, 'storeCategoryLmsLink'])->whereNumber('category')->middleware('throttle:20,1');
        Route::delete('categories/{category}/lms-links/{link}', [AdminCommerce::class, 'deleteCategoryLmsLink'])->whereNumber(['category', 'link'])->middleware('throttle:20,1');
        Route::post('categories/{category}/spec-templates', [AdminCommerce::class, 'storeCategorySpecTemplate'])->whereNumber('category')->middleware('throttle:20,1');
        Route::delete('categories/{category}/spec-templates/{template}', [AdminCommerce::class, 'deleteCategorySpecTemplate'])->whereNumber(['category', 'template'])->middleware('throttle:20,1');
        Route::post('categories/{category}/spec-templates/{template}/fields', [AdminCommerce::class, 'storeCategorySpecField'])->whereNumber(['category', 'template'])->middleware('throttle:20,1');
        Route::delete('categories/{category}/spec-templates/{template}/fields/{field}', [AdminCommerce::class, 'deleteCategorySpecField'])->whereNumber(['category', 'template', 'field'])->middleware('throttle:20,1');
        Route::post('products', [AdminCommerce::class, 'storeProduct'])->middleware('throttle:20,1');
        Route::post('products/{product}/duplicate', [AdminCommerce::class, 'duplicateProduct'])->whereNumber('product')->middleware('throttle:20,1');
        Route::post('products/{product}/toggle', [AdminCommerce::class, 'deactivateProduct'])->whereNumber('product')->middleware('throttle:20,1');
        Route::post('products/{product}/stock', [AdminCommerce::class, 'adjustProductStock'])->whereNumber('product')->middleware('throttle:20,1');
        Route::post('products/{product}/regional-stock', [AdminCommerce::class, 'storeProductRegionalStock'])->whereNumber('product')->middleware('throttle:20,1');
        Route::post('products/{product}/specs', [AdminCommerce::class, 'storeProductSpec'])->whereNumber('product')->middleware('throttle:20,1');
        Route::delete('products/{product}/specs/{spec}', [AdminCommerce::class, 'deleteProductSpec'])->whereNumber(['product', 'spec'])->middleware('throttle:20,1');
        Route::post('products/{product}/advanced-specs', [AdminCommerce::class, 'storeAdvancedProductSpec'])->whereNumber('product')->middleware('throttle:20,1');
        Route::delete('products/{product}/advanced-specs/{spec}', [AdminCommerce::class, 'deleteAdvancedProductSpec'])->whereNumber(['product', 'spec'])->middleware('throttle:20,1');
        Route::post('products/{product}/reviews/{review}', [AdminCommerce::class, 'updateProductReview'])->whereNumber(['product', 'review'])->middleware('throttle:20,1');
        Route::post('products/{product}/marketplace-prices', [AdminCommerce::class, 'storeMarketplaceProductPrice'])->whereNumber('product')->middleware('throttle:20,1');
        Route::post('products/{product}/marketplace-prices/{price}/toggle', [AdminCommerce::class, 'toggleMarketplaceProductPrice'])->whereNumber(['product', 'price'])->middleware('throttle:20,1');
        Route::post('products/{product}/vendor-prices', [AdminCommerce::class, 'storeVendorProductPrice'])->whereNumber('product')->middleware('throttle:20,1');
        Route::post('products/{product}/vendor-prices/{price}/toggle', [AdminCommerce::class, 'toggleVendorProductPrice'])->whereNumber(['product', 'price'])->middleware('throttle:20,1');
        Route::post('products/{product}/documents', [AdminCommerce::class, 'storeProductDocument'])->whereNumber('product')->middleware('throttle:20,1');
        Route::delete('products/{product}/documents/{document}', [AdminCommerce::class, 'deleteProductDocument'])->whereNumber(['product', 'document'])->middleware('throttle:20,1');
        Route::post('products/{product}/related', [AdminCommerce::class, 'storeProductRelated'])->whereNumber('product')->middleware('throttle:20,1');
        Route::delete('products/{product}/related/{related}', [AdminCommerce::class, 'deleteProductRelated'])->whereNumber(['product', 'related'])->middleware('throttle:20,1');
        Route::post('products/{product}/lms-links', [AdminCommerce::class, 'storeProductLmsLink'])->whereNumber('product')->middleware('throttle:20,1');
        Route::post('products/{product}/seo', [AdminCommerce::class, 'updateProductSeo'])->whereNumber('product')->middleware('throttle:20,1');
        Route::post('vendors', [AdminCommerce::class, 'storeVendor'])->middleware('throttle:20,1');
        Route::post('vendors/{vendor}/status', [AdminCommerce::class, 'updateVendorStatus'])->whereNumber('vendor')->middleware('throttle:20,1');
        Route::post('vendor-documents/{document}/status', [AdminCommerce::class, 'updateVendorDocumentStatus'])->whereNumber('document')->middleware('throttle:20,1');
        Route::post('vendor-products/{product}/approve', [AdminCommerce::class, 'approveVendorProduct'])->whereNumber('product')->middleware('throttle:20,1');
        Route::post('vendor-products/{product}/reject', [AdminCommerce::class, 'rejectVendorProduct'])->whereNumber('product')->middleware('throttle:20,1');
        Route::post('users', [AdminCommerce::class, 'storeUser'])->middleware('throttle:20,1');
        Route::post('users/invitations', [AdminCommerce::class, 'storeAdminInvitation'])->middleware('throttle:20,1');
        Route::post('users/permissions', [AdminCommerce::class, 'storePermission'])->middleware('throttle:20,1');
        Route::post('users/roles/{role}/permissions/{permission}', [AdminCommerce::class, 'toggleRolePermission'])->whereNumber(['role', 'permission'])->middleware('throttle:20,1');
        Route::post('users/{user}/country-access', [AdminCommerce::class, 'assignUserCountryAccess'])->whereNumber('user')->middleware('throttle:20,1');
        Route::post('users/{user}/seller-access', [AdminCommerce::class, 'assignUserSellerAccess'])->whereNumber('user')->middleware('throttle:20,1');
        Route::post('lms/courses', [AdminCommerce::class, 'storeLmsCourse'])->middleware('throttle:20,1');
        Route::post('lms/courses/{course}/toggle', [AdminCommerce::class, 'toggleLmsCourse'])->whereNumber('course')->middleware('throttle:20,1');
        Route::post('lms/courses/{course}/modules', [AdminCommerce::class, 'storeLmsModule'])->whereNumber('course')->middleware('throttle:20,1');
        Route::post('lms/courses/{course}/projects', [AdminCommerce::class, 'storeLmsProject'])->whereNumber('course')->middleware('throttle:20,1');
        Route::post('lms/courses/{course}/products', [AdminCommerce::class, 'storeLmsProductLink'])->whereNumber('course')->middleware('throttle:20,1');
        Route::post('lms/courses/{course}/lessons/{lesson}/files', [AdminCommerce::class, 'storeLmsLessonFile'])->whereNumber(['course', 'lesson'])->middleware('throttle:20,1');
        Route::post('lms/lessons', [AdminCommerce::class, 'storeLmsLesson'])->middleware('throttle:20,1');
        Route::post('lms/enrollments/{enrollment}/certificate', [AdminCommerce::class, 'issueLmsCertificate'])->whereNumber('enrollment')->middleware('throttle:20,1');
        Route::post('lms/certificates/{certificate}/revoke', [AdminCommerce::class, 'revokeLmsCertificate'])->whereNumber('certificate')->middleware('throttle:20,1');
        Route::post('inventory/warehouses', [AdminCommerce::class, 'storeWarehouse'])->middleware('throttle:20,1');
        Route::post('inventory/stocks', [AdminCommerce::class, 'adjustInventoryStock'])->middleware('throttle:20,1');
        Route::post('inventory/transfers', [AdminCommerce::class, 'transferInventoryStock'])->middleware('throttle:20,1');
        Route::post('inventory/reservations', [AdminCommerce::class, 'reserveInventoryStock'])->middleware('throttle:20,1');
        Route::post('inventory/reservations/{reservation}/release', [AdminCommerce::class, 'releaseInventoryReservation'])->whereNumber('reservation')->middleware('throttle:20,1');
        Route::post('inventory/low-stock/generate', [AdminCommerce::class, 'generateLowStockAlerts'])->middleware('throttle:10,1');
        Route::post('inventory/low-stock/{alert}/action', [AdminCommerce::class, 'updateLowStockAlert'])->whereNumber('alert')->middleware('throttle:20,1');
        Route::post('pos/terminals', [AdminCommerce::class, 'storePosTerminal'])->middleware('throttle:20,1');
        Route::post('pos/sessions/open', [AdminCommerce::class, 'openPosSession'])->middleware('throttle:20,1');
        Route::post('pos/sessions/{session}/close', [AdminCommerce::class, 'closePosSession'])->whereNumber('session')->middleware('throttle:20,1');
        Route::post('pos/payment-methods', [AdminCommerce::class, 'storePosPaymentMethod'])->middleware('throttle:20,1');
        Route::post('pos/payment-methods/{method}/toggle', [AdminCommerce::class, 'togglePosPaymentMethod'])->whereNumber('method')->middleware('throttle:20,1');
        Route::post('pos/sales/{sale}/refunds', [AdminCommerce::class, 'storePosRefund'])->whereNumber('sale')->middleware('throttle:20,1');
        Route::post('pos/offline-sync-events', [AdminCommerce::class, 'storePosOfflineSyncEvent'])->middleware('throttle:20,1');
        Route::post('pos/offline-sync-events/{event}/status', [AdminCommerce::class, 'updatePosOfflineSyncEvent'])->whereNumber('event')->middleware('throttle:20,1');

        Route::get('marketing', [AdminDash::class, 'marketing'])->middleware('admin.web.permission:campaigns.view');
        Route::get('marketing/crm', [AdminDash::class, 'crm'])->middleware('admin.web.permission:customers.view');
        Route::get('marketing/customer-imports', [AdminCustomerImport::class, 'index'])->middleware('admin.web.permission:customers.import');
        Route::post('marketing/customer-imports/preview', [AdminCustomerImport::class, 'preview'])->middleware(['admin.web.permission:customers.import', 'throttle:10,1']);
        Route::post('marketing/customer-imports', [AdminCustomerImport::class, 'execute'])->middleware(['admin.web.permission:customers.import', 'throttle:5,1']);
        Route::get('marketing/customer-imports/{import}', [AdminCustomerImport::class, 'show'])->whereNumber('import')->middleware('admin.web.permission:customers.view');
        Route::get('marketing/customer-imports/{import}/errors.csv', [AdminCustomerImport::class, 'errors'])->whereNumber('import')->middleware('admin.web.permission:customers.export');
        Route::get('marketing/customers/export', [AdminCustomerData::class, 'export'])->middleware('admin.web.permission:customers.export');
        Route::get('marketing/newsletter', [AdminDash::class, 'newsletter'])->middleware('admin.web.permission:campaigns.view');
        Route::get('marketing/email', [AdminDash::class, 'emailMarketing'])->middleware('admin.web.permission:campaigns.view');
        Route::get('marketing/automation', [AdminDash::class, 'automation'])->middleware('admin.web.permission:campaigns.view');
        Route::get('marketing/abandoned-carts', [AdminDash::class, 'abandonedCarts'])->middleware('admin.web.permission:campaigns.view');
        Route::get('marketing/whatsapp', [AdminDash::class, 'whatsapp'])->middleware('admin.web.permission:campaigns.view');
        Route::get('marketing/analytics', [AdminDash::class, 'marketingAnalytics'])->middleware('admin.web.permission:campaigns.view');
        Route::get('marketing/settings', [AdminDash::class, 'marketingSettings'])->middleware('admin.web.permission:email.providers.manage');
        Route::get('marketing/audit', [AdminDash::class, 'marketingAudit'])->middleware('admin.web.permission:campaigns.view');

        Route::post('marketing/segments', [AdminMarketing::class, 'storeSegment'])->middleware(['admin.web.permission:campaigns.create', 'throttle:10,1']);
        Route::post('marketing/segments/{segment}/refresh', [AdminMarketing::class, 'refreshSegment'])->whereNumber('segment')->middleware(['admin.web.permission:campaigns.create', 'throttle:10,1']);
        Route::post('marketing/newsletter/templates', [AdminMarketing::class, 'storeNewsletterTemplate'])->middleware(['admin.web.permission:email.templates.manage', 'throttle:10,1']);
        Route::post('marketing/newsletter/campaigns', [AdminMarketing::class, 'storeNewsletterCampaign'])->middleware(['admin.web.permission:campaigns.create', 'throttle:10,1']);
        Route::post('marketing/newsletter/campaigns/{campaign}/queue', [AdminMarketing::class, 'queueNewsletterCampaign'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.send', 'throttle:10,1']);
        Route::post('marketing/newsletter/campaigns/{campaign}/send-test', [AdminMarketing::class, 'sendNewsletterCampaignTest'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.test', 'throttle:10,1']);
        Route::post('marketing/newsletter/campaigns/{campaign}/approve', [AdminMarketing::class, 'approveNewsletterCampaign'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.approve', 'throttle:10,1']);
        Route::post('marketing/newsletter/campaigns/{campaign}/pause', [AdminMarketing::class, 'pauseNewsletterCampaign'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.send', 'throttle:10,1']);
        Route::post('marketing/newsletter/campaigns/{campaign}/resume', [AdminMarketing::class, 'resumeNewsletterCampaign'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.send', 'throttle:10,1']);
        Route::post('marketing/newsletter/campaigns/{campaign}/cancel', [AdminMarketing::class, 'cancelNewsletterCampaign'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.send', 'throttle:10,1']);
        Route::post('marketing/email/templates', [AdminMarketing::class, 'storeEmailTemplate'])->middleware(['admin.web.permission:email.templates.manage', 'throttle:10,1']);
        Route::post('marketing/email/campaigns', [AdminMarketing::class, 'storeEmailCampaign'])->middleware(['admin.web.permission:campaigns.create', 'throttle:10,1']);
        Route::post('marketing/email/campaigns/{campaign}/queue', [AdminMarketing::class, 'queueEmailCampaign'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.send', 'throttle:10,1']);
        Route::post('marketing/email/campaigns/{campaign}/send-test', [AdminMarketing::class, 'sendEmailCampaignTest'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.test', 'throttle:10,1']);
        Route::post('marketing/email/campaigns/{campaign}/approve', [AdminMarketing::class, 'approveEmailCampaign'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.approve', 'throttle:10,1']);
        Route::post('marketing/email/campaigns/{campaign}/pause', [AdminMarketing::class, 'pauseEmailCampaign'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.send', 'throttle:10,1']);
        Route::post('marketing/email/campaigns/{campaign}/resume', [AdminMarketing::class, 'resumeEmailCampaign'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.send', 'throttle:10,1']);
        Route::post('marketing/email/campaigns/{campaign}/cancel', [AdminMarketing::class, 'cancelEmailCampaign'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.send', 'throttle:10,1']);
        Route::post('marketing/whatsapp/templates', [AdminMarketing::class, 'storeWhatsappTemplate'])->middleware(['admin.web.permission:email.templates.manage', 'throttle:10,1']);
        Route::post('marketing/whatsapp/campaigns', [AdminMarketing::class, 'storeWhatsappCampaign'])->middleware(['admin.web.permission:campaigns.create', 'throttle:10,1']);
        Route::post('marketing/whatsapp/campaigns/{campaign}/queue', [AdminMarketing::class, 'queueWhatsappCampaign'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.send', 'throttle:10,1']);
        Route::post('marketing/whatsapp/campaigns/{campaign}/send-test', [AdminMarketing::class, 'sendWhatsappCampaignTest'])->whereNumber('campaign')->middleware(['admin.web.permission:campaigns.test', 'throttle:10,1']);
        Route::post('marketing/settings', [AdminMarketing::class, 'updateMarketingSettings'])->middleware(['admin.web.permission:email.providers.manage', 'throttle:10,1']);
        Route::post('marketing/settings/email-provider', [AdminMarketing::class, 'updateEmailProvider'])->middleware(['admin.web.permission:email.providers.manage', 'throttle:10,1']);
        Route::post('marketing/settings/email-provider/test-marketing', [AdminMarketing::class, 'testMarketingProvider'])->middleware(['admin.web.permission:email.providers.manage', 'throttle:5,1']);
        Route::post('marketing/settings/email-provider/test-transactional', [AdminMarketing::class, 'testTransactionalProvider'])->middleware(['admin.web.permission:email.providers.manage', 'throttle:5,1']);
        Route::post('marketing/settings/senders/{sender}', [AdminMarketing::class, 'updateEmailSenderProfile'])->whereNumber('sender')->middleware(['admin.web.permission:email.providers.manage', 'throttle:10,1']);

        // Commerce ops (adaptation modules) — read pages
        Route::get('affiliate', [AdminDash::class, 'affiliate']);
        Route::get('promotions', [AdminDash::class, 'promotions']);
        Route::get('procurement', [AdminDash::class, 'procurement']);
        Route::get('quotations', [AdminDash::class, 'quotations']);
        Route::get('quotations/{quotation}/preview', [AdminDash::class, 'quotationPreview'])->whereNumber('quotation');
        Route::get('expenses', [AdminDash::class, 'expenses']);
        Route::get('payments', [AdminDash::class, 'payments']);
        Route::get('support', [AdminDash::class, 'support']);
        Route::get('applications', [AdminDash::class, 'applications']);
        Route::get('region-stock', [AdminDash::class, 'regionStock']);

        // Orders (permission placeholders pending web-console RBAC:
        // admin.orders.view / admin.orders.update — currently guarded by admin.web roles)
        Route::get('orders', [AdminDash::class, 'orders']);
        Route::get('orders/{id}', [AdminDash::class, 'order'])->whereNumber('id');
        Route::get('orders/{id}/invoice', [AdminDash::class, 'invoice'])->whereNumber('id');

        // Commerce ops — guarded config actions (server-side; no live gateways)
        Route::post('payments/providers/{provider}/toggle', [AdminCommerce::class, 'toggleProvider'])->whereNumber('provider')->middleware('throttle:20,1');
        Route::post('payments/payouts/{payout}/approve', [AdminCommerce::class, 'approvePayout'])->whereNumber('payout')->middleware('throttle:20,1');
        Route::post('payments/payouts/{payout}/mark-paid', [AdminCommerce::class, 'markPayoutPaid'])->whereNumber('payout')->middleware('throttle:20,1');
        Route::post('promotions/coupons', [AdminCommerce::class, 'storeCoupon'])->middleware('throttle:20,1');
        Route::post('promotions/coupons/{coupon}/toggle', [AdminCommerce::class, 'toggleCoupon'])->whereNumber('coupon')->middleware('throttle:20,1');
        Route::post('affiliate/{affiliate}/approve', [AdminCommerce::class, 'approveAffiliate'])->whereNumber('affiliate')->middleware('throttle:20,1');
        Route::post('affiliate/commissions/{commission}/approve', [AdminCommerce::class, 'approveCommission'])->whereNumber('commission')->middleware('throttle:20,1');
        Route::post('expenses', [AdminCommerce::class, 'storeExpense'])->middleware('throttle:20,1');
        Route::post('applications/{type}/{id}/status', [AdminCommerce::class, 'updateApplicationStatus'])->whereNumber('id')->middleware('throttle:20,1');
        Route::post('region-stock/rules/{rule}/toggle', [AdminCommerce::class, 'toggleStockRule'])->whereNumber('rule')->middleware('throttle:20,1');
        Route::post('users/{user}/send-reset', [AdminCommerce::class, 'sendPasswordReset'])->whereNumber('user')->middleware('throttle:20,1');
        Route::post('orders/{order}/status', [AdminCommerce::class, 'updateOrderStatus'])->whereNumber('order')->middleware('throttle:20,1');
        Route::post('orders/{order}/tracking', [AdminCommerce::class, 'updateOrderTracking'])->whereNumber('order')->middleware('throttle:20,1');
        Route::get('reviews', [AdminDash::class, 'reviews']);
        Route::get('rfqs', [AdminDash::class, 'rfqs']);
        Route::get('rfqs/{id}', [AdminDash::class, 'rfq'])->whereNumber('id');
        Route::post('rfqs/{rfq}/status', [AdminCommerce::class, 'updateRfqStatus'])->whereNumber('rfq')->middleware('throttle:20,1');
        Route::post('rfqs/{rfq}/quotations', [AdminCommerce::class, 'storeRfqQuotation'])->whereNumber('rfq')->middleware('throttle:20,1');
        Route::post('quotations/{quotation}/status', [AdminCommerce::class, 'updateQuotationStatus'])->whereNumber('quotation')->middleware('throttle:20,1');
        Route::post('quotations/{quotation}/items', [AdminCommerce::class, 'storeQuotationItem'])->whereNumber('quotation')->middleware('throttle:20,1');
        Route::delete('quotations/{quotation}/items/{item}', [AdminCommerce::class, 'deleteQuotationItem'])->whereNumber(['quotation', 'item'])->middleware('throttle:20,1');
        Route::post('support/tickets', [AdminCommerce::class, 'storeSupportTicket'])->middleware('throttle:20,1');
        Route::post('support/tickets/{ticket}', [AdminCommerce::class, 'updateSupportTicket'])->whereNumber('ticket')->middleware('throttle:20,1');
        Route::post('support/tickets/{ticket}/escalate', [AdminCommerce::class, 'escalateSupportTicket'])->whereNumber('ticket')->middleware('throttle:20,1');
        Route::post('support/tickets/{ticket}/messages', [AdminCommerce::class, 'storeSupportTicketMessage'])->whereNumber('ticket')->middleware('throttle:20,1');
    });
});

// Public marketplace
Route::post('/marketplace/preference', [MarketplacePreferenceController::class, 'store'])
    ->middleware('throttle:20,1')
    ->name('marketplace.preference');
Route::get('/sso/start', [SsoController::class, 'start'])
    ->middleware(['auth', 'throttle:10,1'])
    ->name('sso.start');
Route::get('/sso/consume', [SsoController::class, 'consume'])
    ->middleware('throttle:20,1')
    ->name('sso.consume');
Route::redirect('/learn', '/en/lms', 301);
Route::redirect('/learning', '/en/lms', 301);
Route::get('/learn/projects/{slug}', [LmsPageController::class, 'project']);
Route::redirect('/', '/en', 301);
// Stitch "Precision Engineering" redesign preview (noindex; does not touch the
// live homepage/layout). Promote to the live home only after review.
Route::get('/preview/home', [RedesignController::class, 'home']);
Route::get('/categories', fn (Request $request) => redirect()->to('/en/categories'.($request->getQueryString() ? '?'.$request->getQueryString() : ''), 301));
Route::get('/categories/{slug}', fn (Request $request, string $slug) => redirect()->to('/en/categories/'.$slug.($request->getQueryString() ? '?'.$request->getQueryString() : ''), 301))->where('slug', '[a-z0-9\-]+');
Route::get('/manufacturer/{slug}', [SeoLandingController::class, 'manufacturer'])->where('slug', '[a-z0-9\-]+')->name('manufacturer.show');
Route::get('/manufacturers/{slug}', fn (Request $request, string $slug) => redirect()->to('/manufacturer/'.$slug.($request->getQueryString() ? '?'.$request->getQueryString() : ''), 301))->where('slug', '[a-z0-9\-]+');
Route::get('/brand/{slug}', [SeoLandingController::class, 'brand'])->where('slug', '[a-z0-9\-]+')->name('brand.show');
Route::get('/brands/{slug}', fn (Request $request, string $slug) => redirect()->to('/brand/'.$slug.($request->getQueryString() ? '?'.$request->getQueryString() : ''), 301))->where('slug', '[a-z0-9\-]+');
Route::get('/mpn/{mpn}', [SeoLandingController::class, 'mpn'])->where('mpn', '[A-Za-z0-9\\.\\-_]+');
Route::get('/technologies/{slug}', [SeoLandingController::class, 'technology'])->where('slug', '[a-z0-9\-]+');
Route::get('/applications/{slug}', [SeoLandingController::class, 'application'])->where('slug', '[a-z0-9\-]+');
Route::get('/countries/{code}', [SeoLandingController::class, 'country'])->where('code', '[A-Za-z]{2,3}');
Route::get('/products', fn (Request $request) => redirect()->to('/en/products'.($request->getQueryString() ? '?'.$request->getQueryString() : ''), 301))->name('products.index');
Route::post('/products/{slug}/reviews', [ProductPageController::class, 'storeReview'])->where('slug', '[a-z0-9\-]+')->middleware('throttle:4,1')->name('products.reviews.store');
Route::get('/products/{slug}', fn (Request $request, string $slug) => redirect()->to('/en/products/'.$slug.($request->getQueryString() ? '?'.$request->getQueryString() : ''), 301))->where('slug', '[a-z0-9\-]+')->name('products.show');
Route::get('/cart', [CartPageController::class, 'show'])->name('cart.show');
Route::post('/cart/items', [CartPageController::class, 'add'])->middleware('throttle:30,1')->name('cart.items.add');
Route::patch('/cart/items/{item}', [CartPageController::class, 'update'])->whereNumber('item')->middleware('throttle:30,1')->name('cart.items.update');
Route::delete('/cart/items/{item}', [CartPageController::class, 'remove'])->whereNumber('item')->middleware('throttle:30,1')->name('cart.items.remove');
Route::get('/checkout', [CartPageController::class, 'checkout'])->name('checkout.show');
Route::post('/checkout', [CartPageController::class, 'placeOrder'])->middleware('throttle:10,1')->name('checkout.place');
Route::get('/checkout/thank-you/{orderNumber}', [CartPageController::class, 'thankYou'])->where('orderNumber', '[A-Z0-9\\-]+')->name('checkout.thank-you');
Route::get('/rfq', fn (Request $request) => redirect()->to('/en/rfq'.($request->getQueryString() ? '?'.$request->getQueryString() : ''), 301))->name('rfq.create');
Route::post('/rfq', [RfqPageController::class, 'store'])->middleware('throttle:6,1')->name('rfq.store');
Route::get('/sitemap.xml', SitemapController::class);
Route::get('/sitemaps/{section}-{page}.xml', [SitemapController::class, 'section'])
    ->whereIn('section', ['pages', 'categories', 'brands', 'manufacturers', 'products'])
    ->whereNumber('page');

// Password reset pages (the reset email links to the named password.reset route)
Route::get('/forgot-password', [PasswordResetController::class, 'showLinkRequest'])->name('password.request');
Route::post('/forgot-password', [PasswordResetController::class, 'sendLink'])->middleware('throttle:6,1')->name('password.email');
Route::get('/reset-password/{token}', [PasswordResetController::class, 'showResetForm'])->name('password.reset');
Route::post('/reset-password', [PasswordResetController::class, 'reset'])->middleware('throttle:6,1')->name('password.update');

// Public seller/partner landing pages
Route::redirect('/sell-on-neogiga', '/en/sell-on-neogiga', 301);
Route::redirect('/distributors', '/en/distributors', 301);
Route::redirect('/ai-commerce', '/en/ai-commerce', 301);
Route::post('/ai-commerce/build', [AiCommercePageController::class, 'build'])->middleware('throttle:12,1');
Route::post('/ai-commerce/save', [AiCommercePageController::class, 'save'])->middleware('throttle:8,1');
Route::redirect('/seller-early-access', '/en/seller-early-access', 301);

if (config('neogiga_global.features.locale_prefix_routes', true)) {
    $localePrefixes = array_keys(config('neogiga_global.prefixes', []));

    Route::prefix('{localePrefix}')
        ->whereIn('localePrefix', $localePrefixes)
        ->group(function () {
            Route::get('/', fn (string $localePrefix) => app(LandingController::class)())->name('localized.home');
            Route::get('/products', fn (string $localePrefix, Request $request) => app(ProductPageController::class)->index($request))->name('localized.products.index');
            Route::get('/products/{slug}', fn (string $localePrefix, string $slug) => app(ProductPageController::class)->show($slug))->where('slug', '[a-z0-9\-]+')->name('localized.products.show');
            Route::get('/categories', fn (string $localePrefix) => app(CategoryController::class)->index())->name('localized.categories.index');
            Route::get('/categories/{slug}', fn (string $localePrefix, string $slug) => app(CategoryController::class)->show($slug))->where('slug', '[a-z0-9\-]+')->name('localized.categories.show');
            Route::get('/manufacturer/{slug}', fn (string $localePrefix, string $slug) => app(SeoLandingController::class)->manufacturer($slug))->where('slug', '[a-z0-9\-]+')->name('localized.manufacturer.show');
            Route::get('/brand/{slug}', fn (string $localePrefix, string $slug) => app(SeoLandingController::class)->brand($slug))->where('slug', '[a-z0-9\-]+')->name('localized.brand.show');
            Route::get('/brands', fn (string $localePrefix) => redirect('/categories'))->name('localized.brands.index');
            Route::get('/lms', fn (string $localePrefix) => app(LmsPageController::class)->index(app(CourseCatalogService::class)))->name('localized.lms.index');
            Route::get('/projects', fn (string $localePrefix) => redirect('/learn'))->name('localized.projects.index');
            Route::get('/rfq', fn (string $localePrefix, Request $request) => app(RfqPageController::class)->create($request))->name('localized.rfq.create');
            Route::get('/sell-on-neogiga', fn (string $localePrefix) => app(SellOnNeoGigaController::class)->sell())->name('localized.seller');
            Route::get('/seller-early-access', fn (string $localePrefix) => app(SellOnNeoGigaController::class)->earlyAccess())->name('localized.seller.early-access');
            Route::get('/distributors', fn (string $localePrefix) => app(SellOnNeoGigaController::class)->distributors())->name('localized.distributors');
            Route::get('/ai-commerce', fn (string $localePrefix, Request $request) => app(AiCommercePageController::class)->index($request, app(CommerceAiService::class)))->name('localized.ai');
        });
}

// Global Commerce Stage 1: marketplace country selector / landing page.
// Constrained to the 25 seeded url_prefix codes only — cannot collide with
// any existing top-level route above (none of them are 2-8 letter codes).
Route::get('/{prefix}', [MarketplaceLandingController::class, 'show'])
    ->whereIn('prefix', ['in', 'np', 'bd', 'lk', 'pk', 'bt', 'mv', 'ae', 'sa', 'qa', 'om', 'kw', 'us', 'ca', 'uk', 'de', 'fr', 'it', 'es', 'nl', 'au', 'nz', 'br', 'za', 'ke'])
    ->name('marketplace.landing');
